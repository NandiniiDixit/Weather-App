
let appid = 'appid=3598a8acc5cc2ea4cc6731602261505e';
let url = 'http://api.openweathermap.org/data/2.5/weather?q=London&'+appid;
