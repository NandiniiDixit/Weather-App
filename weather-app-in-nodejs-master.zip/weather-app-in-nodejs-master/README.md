# weather-app-in-nodejs

Programmer Blog: https://programmerblog.net/

Source code for article on NodeJS PassportJS login with MySQL.

Following articles are performed in thsi tutorial.

  1. Register on Open Weather Map website.

  2. Generate a weather app in nodejs using express command line tool

  3. Create an HTML form and a table to display data

  4. Create a  /weather route to fetch weather for a city
  
  
Read detailed tutorial at: http://programmerblog.net/weather-app-in-nodejs/
